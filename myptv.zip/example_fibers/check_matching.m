clear all
close all
clc

data = load(fullfile('particles'));
data_proc = load(fullfile('./processed_data/particles_alu10d10_100_1'));

figure
scatter3(data(:,2), data(:,3), data(:,1),35,'filled','b'); hold on
scatter3(data_proc(:,2), data_proc(:,3), data_proc(:,1),25,'filled','r'); 
daspect([1 1 1])
