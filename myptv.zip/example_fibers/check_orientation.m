clear all
close all
clc

data_pos = load(fullfile('./trajectories'));
data_ori = load(fullfile('./fiber_orientations'));
data_ori(:,2:4) = data_ori(:,2:4)./vecnorm(data_ori(:,2:4),2,2);

data_proc_pos = load(fullfile('./processed_data/trajectories_alu10d10_100_1'));
data_proc_ori = load(fullfile('./processed_data/ori_alu10d10_100_1'));
data_proc_ori(:,2:4) = data_proc_ori(:,2:4)./vecnorm(data_proc_ori(:,2:4),2,2);

length = 0.5;

figure
quiver3(data_pos(:,3), data_pos(:,4), data_pos(:,2), data_ori(:,3), data_ori(:,4), data_ori(:,2),length,'color','b'); hold on
quiver3(data_pos(:,3), data_pos(:,4), data_pos(:,2), -data_ori(:,3), -data_ori(:,4), -data_ori(:,2),length,'color','b'); hold on
quiver3(data_proc_pos(:,3), data_proc_pos(:,4), data_proc_pos(:,2), data_proc_ori(:,3), data_proc_ori(:,4), data_proc_ori(:,2),length,'color','r'); hold on
quiver3(data_proc_pos(:,3), data_proc_pos(:,4), data_proc_pos(:,2), -data_proc_ori(:,3), -data_proc_ori(:,4), -data_proc_ori(:,2),length,'color','r'); hold on
% legend('with sieve', 'without sieve');
daspect([1 1 1])



% indbad = find(isnan(data(:,2)));
% data(indbad,:) = [];
% indbad = find(isnan(data_proc(:,2)));
% data_proc(indbad,:) = [];