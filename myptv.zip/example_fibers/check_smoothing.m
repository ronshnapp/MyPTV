clear all
close all
clc

% data = load(fullfile('./traj_ori'));
% data_proc = load(fullfile('./processed_data/ws15_traj_ori_alu10d10_100_1'));
data = load(fullfile('./stitched_traj_ori'));
data_proc = load(fullfile('./processed_data/stitched_ws15_traj_ori_alu10d10_100_1'));
data(:,11:13) = data(:,11:13)./vecnorm(data(:,11:13),2,2);
data_proc(:,11:13) = data_proc(:,11:13)./vecnorm(data_proc(:,11:13),2,2);



length = 0.5;

figure
quiver3(data(:,3), data(:,4), data(:,2), data(:,3), data(:,4), data(:,2),length,'color','b'); hold on
quiver3(data(:,3), data(:,4), data(:,2), -data(:,3), -data(:,4), -data(:,2),length,'color','b'); hold on
quiver3(data_proc(:,3), data_proc(:,4), data_proc(:,2), data_proc(:,3), data_proc(:,4), data_proc(:,2),length,'color','r'); hold on
quiver3(data_proc(:,3), data_proc(:,4), data_proc(:,2), -data_proc(:,3), -data_proc(:,4), -data_proc(:,2),length,'color','r'); hold on
% legend('with sieve', 'without sieve');
daspect([1 1 1])
xlim([-50 200])
ylim([-200 50])
zlim([0 400])
xlabel('x')
ylabel('y')
zlabel('z')

figure
ksdensity(vecnorm(data(:,14:16),2,2)); hold on
ksdensity(vecnorm(data_proc(:,14:16),2,2)./250);