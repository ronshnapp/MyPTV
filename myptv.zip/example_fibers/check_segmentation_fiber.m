%% check ori segmentation streakline

clear all;
close all;
clc;

cam = 1;

data = load(fullfile(sprintf('./blobs_cam%i_directions',cam)));
data_proc = load(fullfile(sprintf('./processed_data/blobs_20240509_alu10d10_100_noB_0%i_01_directions',cam)));

% Extract coordinates and errors
coord = data(:, 1:2);
ori = data(:, 7:8);
f = data(:, 6);
t = unique(f);
x = coord(:,1);
y = coord(:,2);
px = ori(:,1)./vecnorm(ori,2,2);
py = ori(:,2)./vecnorm(ori,2,2);


coord_proc = data_proc(:, 1:2);
ori_proc = data_proc(:, 7:8);
f_proc = data_proc(:, 6);
t_proc = unique(f_proc);
x_proc = coord_proc(:,1);
y_proc = coord_proc(:,2);
px_proc = ori_proc(:,1)./vecnorm(ori_proc,2,2);
py_proc = ori_proc(:,2)./vecnorm(ori_proc,2,2);

t_0 = 0;
t_1 = 4000;

ind = find(f >= t_0 & f <= t_1);
ind_proc = find(f_proc >= t_0 & f_proc <= t_1);

figure
scale = 0.5;
quiver(x_proc(ind_proc), y_proc(ind_proc), px_proc(ind_proc), py_proc(ind_proc), 2*scale,'color','b'); hold on
quiver(x_proc(ind_proc), y_proc(ind_proc), -px_proc(ind_proc), -py_proc(ind_proc), 2*scale,'color','b'); hold on
quiver(x(ind), y(ind), px(ind), py(ind), scale,'color','r'); hold on
quiver(x(ind), y(ind), -px(ind), -py(ind), scale,'color','r'); hold on
xlabel('X Coordinate');
ylabel('Y Coordinate');
colormap('jet'); % You can customize the colormap
xlim([0, 1000]);
ylim([0, 1000]);
daspect([1 1 1])